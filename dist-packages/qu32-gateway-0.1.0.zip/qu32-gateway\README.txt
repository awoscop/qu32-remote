QU32 gateway (runtime build). Needs Node.js 20+ and OpenSSL (Git for Windows includes it).

Windows:   powershell -ExecutionPolicy Bypass -File .\start-gateway.ps1
Mac/Linux: ./start-gateway.sh

First start prints the engineer password ONCE. Data is kept in .qu32-private/ (do not share it).
Set the console IP in the app (Access tab) or with QU32_MIXER_IP. Full guide: qu32-remote/README.md in the repo.
Simulated desk for trials: MOCK_PORT=51325 node gateway/dist/mock-main.js
